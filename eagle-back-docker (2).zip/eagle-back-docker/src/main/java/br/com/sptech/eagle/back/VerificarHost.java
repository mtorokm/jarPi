
package br.com.sptech.eagle.back;

public class VerificarHost {
    private String id_host;
    private String id_totem;

    public String getId_host() {
        return id_host;
    }

    public void setId_host(String id_host) {
        this.id_host = id_host;
    }

    public String getId_totem() {
        return id_totem;
    }

    public void setId_totem(String id_totem) {
        this.id_totem = id_totem;
    }

    @Override
    public String toString() {
        return id_totem;
    }

    
    
    
}
